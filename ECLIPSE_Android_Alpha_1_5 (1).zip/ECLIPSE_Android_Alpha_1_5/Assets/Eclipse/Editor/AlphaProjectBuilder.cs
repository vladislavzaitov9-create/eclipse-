#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor.Build.Reporting;
using System.IO;
using Eclipse.Alpha;

namespace Eclipse.EditorTools
{
    public static class AlphaProjectBuilder
    {
        private const string ScenePath = "Assets/Eclipse/Scenes/EclipseAlphaArena.unity";

        [MenuItem("ECLIPSE Alpha/1. Create Playable Arena")]
        public static void CreateArena()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            RenderSettings.ambientLight = new Color(0.48f,0.48f,0.52f);
            var light = new GameObject("Sun", typeof(Light)); light.GetComponent<Light>().type = LightType.Directional; light.transform.rotation = Quaternion.Euler(50,-30,0);
            CreatePrimitive("Arena Floor", PrimitiveType.Cube, new Vector3(0,-0.5f,0), new Vector3(32,1,32), new Color(0.22f,0.28f,0.25f));
            CreatePrimitive("North Wall", PrimitiveType.Cube, new Vector3(0,1.5f,16), new Vector3(32,3,1), new Color(0.25f,0.25f,0.29f));
            CreatePrimitive("South Wall", PrimitiveType.Cube, new Vector3(0,1.5f,-16), new Vector3(32,3,1), new Color(0.25f,0.25f,0.29f));
            CreatePrimitive("East Wall", PrimitiveType.Cube, new Vector3(16,1.5f,0), new Vector3(1,3,32), new Color(0.25f,0.25f,0.29f));
            CreatePrimitive("West Wall", PrimitiveType.Cube, new Vector3(-16,1.5f,0), new Vector3(1,3,32), new Color(0.25f,0.25f,0.29f));
            var player = GameObject.CreatePrimitive(PrimitiveType.Capsule); player.name="Elian - Player"; player.transform.position=new Vector3(0,1, -8); Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
            player.AddComponent<CharacterController>(); player.AddComponent<AlphaPlayerController>(); player.AddComponent<AlphaCombat>();
            var pivot = new GameObject("Camera Pivot").transform; pivot.SetParent(player.transform,false); pivot.localPosition=Vector3.zero;
            var cameraGO = new GameObject("Main Camera",typeof(Camera),typeof(AudioListener),typeof(AlphaCameraFollow)); cameraGO.tag="MainCamera";
            var follow=cameraGO.GetComponent<AlphaCameraFollow>(); follow.target=player.transform; cameraGO.transform.position=player.transform.position+new Vector3(0,3.4f,-5.5f);
            var cam=cameraGO.GetComponent<Camera>(); cam.fieldOfView=62; cam.nearClipPlane=0.1f;
            CreateEnemy(new Vector3(-5,1,2),false); CreateEnemy(new Vector3(0,1,5),false); CreateEnemy(new Vector3(5,1,2),false);
            CreateEnemy(new Vector3(0,1,11),true);
            var keeper=CreatePrimitive("Archive Keeper",PrimitiveType.Cylinder,new Vector3(-3,1,-1),new Vector3(0.8f,1.8f,0.8f),new Color(0.2f,0.65f,0.75f)); var ki=keeper.AddComponent<AlphaInteractable>(); ki.kind=AlphaInteractable.Kind.Keeper; ki.prompt="Поговорить с хранителем";
            var gate=CreatePrimitive("Ancient Gate",PrimitiveType.Cube,new Vector3(0,2,14),new Vector3(5,4,0.7f),new Color(0.65f,0.48f,0.2f)); var gi=gate.AddComponent<AlphaInteractable>(); gi.kind=AlphaInteractable.Kind.AncientGate; gi.prompt="Открыть древние врата";
            if (!Object.FindObjectOfType<AlphaGameState>()) new GameObject("Game State",typeof(AlphaGameState));
            new GameObject("Mobile HUD",typeof(AlphaMobileHUD));
            for(int i=0;i<8;i++) { float a=i*Mathf.PI/4; var rock=CreatePrimitive("Arena Pillar",PrimitiveType.Cylinder,new Vector3(Mathf.Cos(a)*13,1.5f,Mathf.Sin(a)*13),new Vector3(0.8f,3,0.8f),new Color(0.35f,0.34f,0.32f)); }
            Directory.CreateDirectory("Assets/Eclipse/Scenes");
            EditorSceneManager.SaveScene(scene,ScenePath); EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};
            Selection.activeGameObject=player; Debug.Log("ECLIPSE Alpha arena created. Press Play to test.");
        }

        [MenuItem("ECLIPSE Alpha/2. Configure Android (Portrait HUD, Landscape Game)")]
        public static void ConfigureAndroid()
        {
            PlayerSettings.companyName="ECLIPSE Studio"; PlayerSettings.productName="ECLIPSE: Garden of Eternity";
            PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.Android,"com.eclipse.gardenofeternity.alpha");
            PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
            PlayerSettings.stripEngineCode=true; PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
            EditorUserBuildSettings.androidBuildSystem=AndroidBuildSystem.Gradle;
            Debug.Log("Android player settings configured. Install Android Build Support + SDK + NDK + OpenJDK in Unity Hub.");
        }

        [MenuItem("ECLIPSE Alpha/3. Build APK")]
        public static void BuildApk()
        {
            if (EditorBuildSettings.scenes.Length==0 || !File.Exists(ScenePath)) { Debug.LogError("Create the playable arena first."); return; }
            string path=EditorUtility.SaveFilePanel("Build ECLIPSE APK","","ECLIPSE_Alpha.apk","apk"); if(string.IsNullOrEmpty(path)) return;
            var options=new BuildPlayerOptions { scenes=new[]{ScenePath}, locationPathName=path, target=BuildTarget.Android, options=BuildOptions.None };
            BuildReport report=BuildPipeline.BuildPlayer(options);
            if(report.summary.result==BuildResult.Succeeded) Debug.Log("APK built: "+path+" | "+report.summary.totalSize+" bytes");
            else Debug.LogError("APK build failed: "+report.summary.result+" errors="+report.summary.totalErrors);
        }

        private static GameObject CreateEnemy(Vector3 pos,bool boss)
        {
            var go=GameObject.CreatePrimitive(PrimitiveType.Capsule); go.name=boss?"Boundary Warden - Boss":"Eclipse Guardian"; go.transform.position=pos;
            go.GetComponent<Renderer>().sharedMaterial=MakeMaterial(boss?new Color(0.55f,0.12f,0.18f):new Color(0.65f,0.25f,0.25f));
            var enemy=go.AddComponent<AlphaEnemy>(); enemy.isBoss=boss; enemy.maxHealth=boss?260:60; enemy.attackDamage=boss?18:8; enemy.moveSpeed=boss?1.25f:1.7f;
            return go;
        }
        private static GameObject CreatePrimitive(string name,PrimitiveType type,Vector3 pos,Vector3 scale,Color color)
        {
            var go=GameObject.CreatePrimitive(type); go.name=name; go.transform.position=pos; go.transform.localScale=scale; go.GetComponent<Renderer>().sharedMaterial=MakeMaterial(color); return go;
        }
        private static Material MakeMaterial(Color color)
        {
            Shader shader=Shader.Find("Universal Render Pipeline/Lit"); if(shader==null) shader=Shader.Find("Standard");
            var mat=new Material(shader); mat.color=color; return mat;
        }
    }
}
#endif
