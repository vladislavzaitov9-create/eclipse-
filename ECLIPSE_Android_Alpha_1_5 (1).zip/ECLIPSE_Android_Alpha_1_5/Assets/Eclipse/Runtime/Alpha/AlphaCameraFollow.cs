using UnityEngine;

namespace Eclipse.Alpha
{
    public sealed class AlphaCameraFollow : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0, 3.4f, -5.5f);
        public float smooth = 12f;
        private float yaw;
        private float pitch = 18f;
        public void SetOrbit(float y, float p) { yaw = y; pitch = Mathf.Clamp(p, 5f, 55f); }
        private void LateUpdate()
        {
            if (!target) return;
            Quaternion orbit = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 desired = target.position + orbit * offset;
            transform.position = Vector3.Lerp(transform.position, desired, smooth * Time.deltaTime);
            transform.LookAt(target.position + Vector3.up * 1.35f);
        }
    }
}
