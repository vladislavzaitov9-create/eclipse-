using UnityEngine;

namespace Eclipse.Alpha
{
    public sealed class AlphaCombat : MonoBehaviour
    {
        public float attackDamage = 35f;
        public float attackRange = 3.1f;
        public float attackCooldown = 0.48f;
        private float nextAttack;
        private AlphaPlayerController player;

        private void Awake() { player = GetComponent<AlphaPlayerController>(); }
        public void Attack()
        {
            if (Time.time < nextAttack) return;
            nextAttack = Time.time + attackCooldown;
            Collider[] hits = Physics.OverlapSphere(transform.position + transform.forward * 1.1f, attackRange * 0.55f);
            AlphaEnemy best = null; float bestDistance = float.MaxValue;
            foreach (var hit in hits)
            {
                var enemy = hit.GetComponentInParent<AlphaEnemy>(); if (!enemy) continue;
                Vector3 to = enemy.transform.position - transform.position; to.y = 0;
                if (Vector3.Dot(transform.forward, to.normalized) < 0.15f) continue;
                if (to.sqrMagnitude < bestDistance) { best = enemy; bestDistance = to.sqrMagnitude; }
            }
            if (best) best.TakeDamage(attackDamage);
        }

        public void Special()
        {
            Collider[] hits = Physics.OverlapSphere(transform.position, 4.5f);
            foreach (var hit in hits) { var enemy = hit.GetComponentInParent<AlphaEnemy>(); if (enemy) enemy.TakeDamage(55f); }
        }

        public void DrinkPotion()
        {
            var state = AlphaGameState.Instance;
            if (state && player && state.UsePotion()) player.Heal(45f);
        }
    }
}
