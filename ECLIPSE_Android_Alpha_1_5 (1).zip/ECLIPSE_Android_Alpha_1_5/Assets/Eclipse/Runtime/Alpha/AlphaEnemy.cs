using UnityEngine;

namespace Eclipse.Alpha
{
    public sealed class AlphaEnemy : MonoBehaviour
    {
        public float maxHealth = 60f;
        public float moveSpeed = 1.7f;
        public float attackRange = 1.65f;
        public float attackDamage = 8f;
        public bool isBoss;
        private float health;
        private float attackCooldown;
        private Transform target;
        private bool dead;

        private void Start() { health = maxHealth; var p = FindObjectOfType<AlphaPlayerController>(); if (p) target = p.transform; }
        private void Update()
        {
            if (dead || !target) return;
            float distance = Vector3.Distance(transform.position, target.position);
            if (distance > attackRange)
            {
                Vector3 dir = target.position - transform.position; dir.y = 0;
                if (dir.sqrMagnitude > 0.01f) { transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 5f * Time.deltaTime); transform.position += transform.forward * moveSpeed * Time.deltaTime; }
            }
            else if (attackCooldown <= 0)
            {
                var player = target.GetComponent<AlphaPlayerController>(); if (player) player.Damage(attackDamage);
                attackCooldown = 1.4f;
            }
            attackCooldown -= Time.deltaTime;
        }

        public void TakeDamage(float amount)
        {
            if (dead) return;
            health -= amount;
            if (health <= 0) { dead = true; var state = AlphaGameState.Instance; if (state) state.AddKill(); Destroy(gameObject); }
        }
    }
}
