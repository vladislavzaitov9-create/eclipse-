using UnityEngine;

namespace Eclipse.Alpha
{
    public sealed class AlphaGameState : MonoBehaviour
    {
        public static AlphaGameState Instance { get; private set; }
        public int Level { get; private set; } = 1;
        public int Experience { get; private set; }
        public int DefeatedEnemies { get; private set; }
        public int Potions { get; private set; } = 3;
        public string CurrentObjective { get; private set; } = "Поговорите с хранителем у древних ворот";
        public bool GateOpened { get; private set; }

        private const string SaveKey = "eclipse_alpha_save_v1";

        [System.Serializable]
        private class SaveData
        {
            public int level, experience, defeatedEnemies, potions;
            public bool gateOpened;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Load();
        }

        public void AddKill()
        {
            DefeatedEnemies++;
            Experience += 25;
            if (Experience >= Level * 100) { Experience -= Level * 100; Level++; }
            if (DefeatedEnemies >= 3 && !GateOpened)
                CurrentObjective = "Вернитесь к древним воротам и откройте их";
            Save();
        }

        public bool UsePotion()
        {
            if (Potions <= 0) return false;
            Potions--; Save(); return true;
        }

        public void OpenGate()
        {
            GateOpened = true;
            CurrentObjective = "Альфа-задание завершено. Исследуйте арену.";
            Save();
        }

        public void Save()
        {
            var data = new SaveData { level = Level, experience = Experience, defeatedEnemies = DefeatedEnemies, potions = Potions, gateOpened = GateOpened };
            PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(data));
            PlayerPrefs.Save();
        }

        private void Load()
        {
            if (!PlayerPrefs.HasKey(SaveKey)) return;
            var d = JsonUtility.FromJson<SaveData>(PlayerPrefs.GetString(SaveKey));
            if (d == null) return;
            Level = Mathf.Max(1, d.level); Experience = Mathf.Max(0, d.experience);
            DefeatedEnemies = Mathf.Max(0, d.defeatedEnemies); Potions = Mathf.Clamp(d.potions, 0, 9); GateOpened = d.gateOpened;
            if (GateOpened) CurrentObjective = "Альфа-задание завершено. Исследуйте арену.";
            else if (DefeatedEnemies >= 3) CurrentObjective = "Вернитесь к древним воротам и откройте их";
        }

        public void ResetProgress()
        {
            PlayerPrefs.DeleteKey(SaveKey); Level = 1; Experience = 0; DefeatedEnemies = 0; Potions = 3; GateOpened = false;
            CurrentObjective = "Поговорите с хранителем у древних ворот";
        }
    }
}
