using UnityEngine;

namespace Eclipse.Alpha
{
    public sealed class AlphaInteractable : MonoBehaviour
    {
        public enum Kind { Keeper, AncientGate }
        public Kind kind;
        public float range = 3.2f;
        public string prompt = "Взаимодействовать";
        private Transform player;
        private bool completed;
        private void Start() { var p = FindObjectOfType<AlphaPlayerController>(); if (p) player = p.transform; }
        public bool IsInRange => player && Vector3.Distance(player.position, transform.position) <= range;
        public string Prompt => IsInRange ? prompt : string.Empty;
        public void Interact()
        {
            if (!IsInRange || completed) return;
            var state = AlphaGameState.Instance; if (!state) return;
            if (kind == Kind.Keeper)
            {
                if (state.DefeatedEnemies >= 3) { prompt = "Ворота ждут тебя"; }
                else { prompt = "Победи трёх стражей"; }
            }
            else if (state.DefeatedEnemies >= 3) { state.OpenGate(); completed = true; prompt = "Врата открыты"; }
        }
    }
}
