using UnityEngine;
using UnityEngine.EventSystems;

namespace Eclipse.Alpha
{
    public sealed class AlphaMobileHUD : MonoBehaviour
    {
        private AlphaPlayerController player;
        private AlphaCombat combat;
        private AlphaInteractable nearby;
        private GUIStyle panel, button, title, small;
        private int moveFinger = -1, lookFinger = -1;
        private Vector2 moveOrigin, moveValue, lastLook;
        private Rect attackRect, skillRect, dodgeRect, jumpRect, potionRect, interactRect;

        private void Start() { player = FindObjectOfType<AlphaPlayerController>(); combat = FindObjectOfType<AlphaCombat>(); }
        private void Update()
        {
            if (!player) return;
            nearby = null;
            foreach (var item in FindObjectsOfType<AlphaInteractable>()) if (item.IsInRange) { nearby = item; break; }
            if (!Application.isMobilePlatform) return;
            moveValue = Vector2.zero;
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Began)
                {
                    if (t.position.x < Screen.width * 0.48f && moveFinger < 0) { moveFinger = t.fingerId; moveOrigin = t.position; }
                    else if (t.position.x >= Screen.width * 0.48f && lookFinger < 0) { lookFinger = t.fingerId; lastLook = t.position; }
                }
                if (t.fingerId == moveFinger)
                {
                    moveValue = Vector2.ClampMagnitude((t.position - moveOrigin) / 85f, 1f);
                    if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) moveFinger = -1;
                }
                if (t.fingerId == lookFinger)
                {
                    if (t.phase == TouchPhase.Moved) { player.AddLook(t.position - lastLook); lastLook = t.position; }
                    if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) lookFinger = -1;
                }
            }
            player.SetMove(moveValue);
        }

        private void OnGUI()
        {
            if (!player) return;
            EnsureStyles();
            float s = Mathf.Clamp(Screen.width / 900f, 0.72f, 1.25f);
            float w = 92*s, h = 72*s, margin = 22*s;
            attackRect = new Rect(Screen.width-margin-w, Screen.height-margin-h, w, h);
            skillRect = new Rect(Screen.width-margin-w*2.05f, Screen.height-margin-h*1.48f, w, h);
            dodgeRect = new Rect(Screen.width-margin-w*2.05f, Screen.height-margin-h*0.42f, w, h*0.72f);
            jumpRect = new Rect(Screen.width-margin-w, Screen.height-margin-h*2.05f, w, h*0.72f);
            potionRect = new Rect(Screen.width-margin-w*3.1f, Screen.height-margin-h*0.42f, w, h*0.72f);
            interactRect = new Rect(Screen.width*0.5f-w*0.65f, Screen.height-margin-h*0.8f, w*1.3f, h*0.72f);

            GUI.Box(new Rect(14,14,Mathf.Min(390,Screen.width*0.55f),116), GUIContent.none, panel);
            GUI.Label(new Rect(28,22,350,28), "ECLIPSE  •  ALPHA", title);
            var state = AlphaGameState.Instance;
            GUI.Label(new Rect(28,52,350,24), $"Уровень {state?.Level ?? 1}   HP: {Mathf.CeilToInt(player.Health)}/100", small);
            GUI.Label(new Rect(28,78,350,42), state ? state.CurrentObjective : "Исследуйте арену", small);
            GUI.Label(new Rect(14,Screen.height-42,Screen.width*0.48f,30), "ЛЕВАЯ СТОРОНА: ДВИЖЕНИЕ  •  ПРАВАЯ: КАМЕРА", small);

            if (Application.isMobilePlatform)
            {
                DrawButton(attackRect,"АТАКА"); DrawButton(skillRect,"НАВЫК"); DrawButton(dodgeRect,"РЫВОК"); DrawButton(jumpRect,"ПРЫЖОК"); DrawButton(potionRect,$"ЗЕЛЬЕ ({state?.Potions ?? 0})");
                if (nearby != null) DrawButton(interactRect,"ВЗАИМОДЕЙСТВИЕ");
            }
            else
            {
                GUI.Label(new Rect(14,140,420,90), "WASD — движение\nПКМ + мышь — камера\nЛКМ — атака   Q — навык   Space — прыжок\nShift — рывок   E — взаимодействие   H — зелье", small);
                if (nearby != null && GUI.Button(new Rect(Screen.width-220,20,200,48), nearby.Prompt)) nearby.Interact();
            }
            if (player.Health <= 0 && GUI.Button(new Rect(Screen.width/2-120,Screen.height/2-35,240,70),"ПОВТОРИТЬ ЗАНОВО"))
            { player.Heal(100); var state2 = AlphaGameState.Instance; if (state2) state2.ResetProgress(); }
        }

        private void DrawButton(Rect r, string label)
        {
            if (GUI.Button(r,label,button))
            {
                if (r == attackRect) combat.Attack();
                else if (r == skillRect) combat.Special();
                else if (r == dodgeRect) player.Dodge();
                else if (r == jumpRect) player.Jump();
                else if (r == potionRect) combat.DrinkPotion();
                else if (r == interactRect && nearby) nearby.Interact();
            }
        }
        private void EnsureStyles()
        {
            if (panel != null) return;
            panel = new GUIStyle(GUI.skin.box); panel.normal.background = Texture2D.whiteTexture; panel.normal.textColor = Color.white;
            title = new GUIStyle(GUI.skin.label) { fontSize = 19, fontStyle = FontStyle.Bold, normal = { textColor = new Color(0.95f,0.82f,0.55f) } };
            small = new GUIStyle(GUI.skin.label) { fontSize = 14, wordWrap = true, normal = { textColor = Color.white } };
            button = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, wordWrap = true };
        }
    }
}
