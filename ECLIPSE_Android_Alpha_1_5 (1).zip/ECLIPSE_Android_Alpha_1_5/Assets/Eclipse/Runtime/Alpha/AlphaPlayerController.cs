using UnityEngine;

namespace Eclipse.Alpha
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class AlphaPlayerController : MonoBehaviour
    {
        public float moveSpeed = 4.5f;
        public float rotationSpeed = 12f;
        public float gravity = -22f;
        public float jumpHeight = 1.15f;
        public Transform cameraPivot;
        private CharacterController controller;
        private Vector3 verticalVelocity;
        private Vector2 mobileMove;
        private float cameraYaw;
        private float cameraPitch = 18f;
        private Vector2 lookDelta;
        private bool jumpRequested;
        private bool dodgeRequested;

        public float Health { get; private set; } = 100f;
        public float MaxHealth => 100f;

        private void Awake() { controller = GetComponent<CharacterController>(); }

        private void Update()
        {
            Vector2 move = mobileMove;
            if (!Application.isMobilePlatform)
                move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

            cameraYaw += lookDelta.x * (Application.isMobilePlatform ? 0.12f : 2.2f);
            cameraPitch = Mathf.Clamp(cameraPitch - lookDelta.y * (Application.isMobilePlatform ? 0.10f : 1.5f), 5f, 55f);
            lookDelta = Vector2.zero;
            if (!Application.isMobilePlatform && Input.GetMouseButton(1))
            { cameraYaw += Input.GetAxis("Mouse X") * 2.2f; cameraPitch = Mathf.Clamp(cameraPitch - Input.GetAxis("Mouse Y") * 1.5f, 5f, 55f); }
            if (!Application.isMobilePlatform)
            {
                var combat = GetComponent<AlphaCombat>();
                if (Input.GetMouseButtonDown(0) && combat) combat.Attack();
                if (Input.GetKeyDown(KeyCode.Q) && combat) combat.Special();
                if (Input.GetKeyDown(KeyCode.H) && combat) combat.DrinkPotion();
                if (Input.GetKeyDown(KeyCode.Space)) Jump();
                if (Input.GetKeyDown(KeyCode.LeftShift)) Dodge();
                if (Input.GetKeyDown(KeyCode.E))
                {
                    AlphaInteractable nearest = null; float nearestDistance = 3.5f;
                    foreach (var item in FindObjectsOfType<AlphaInteractable>())
                    {
                        float d = Vector3.Distance(transform.position, item.transform.position);
                        if (d < nearestDistance) { nearest = item; nearestDistance = d; }
                    }
                    if (nearest) nearest.Interact();
                }
            }

            Transform cam = Camera.main ? Camera.main.transform : null;
            var follow = cam ? cam.GetComponent<AlphaCameraFollow>() : null;
            if (follow) follow.SetOrbit(cameraYaw, cameraPitch);
            Vector3 forward = cam ? Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized : transform.forward;
            Vector3 right = cam ? Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized : transform.right;
            Vector3 direction = Vector3.ClampMagnitude(forward * move.y + right * move.x, 1f);
            if (direction.sqrMagnitude > 0.01f)
            {
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
                controller.Move(direction * moveSpeed * (dodgeRequested ? 2.7f : 1f) * Time.deltaTime);
            }
            if (controller.isGrounded && verticalVelocity.y < 0) verticalVelocity.y = -2f;
            if (jumpRequested && controller.isGrounded) verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);
            jumpRequested = false; dodgeRequested = false;

            if (cam && cameraPivot)
            {
                cameraPivot.rotation = Quaternion.Euler(cameraPitch, cameraYaw, 0);
                transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, 0);
            }
        }

        public void SetMove(Vector2 value) { mobileMove = Vector2.ClampMagnitude(value, 1f); }
        public void AddLook(Vector2 delta) { lookDelta += delta; }
        public void Jump() { jumpRequested = true; }
        public void Dodge() { dodgeRequested = true; }
        public void Damage(float amount) { Health = Mathf.Max(0, Health - Mathf.Max(0, amount)); }
        public void Heal(float amount) { Health = Mathf.Min(MaxHealth, Health + Mathf.Max(0, amount)); }
    }
}
